import React from "react";

import VerticalLayout from "./VerticalLayout";

const Layout = ({ children }) => {
  return (
    <div className="layout">
      <VerticalLayout children={children} />
    </div>
  );
};

export default Layout;
