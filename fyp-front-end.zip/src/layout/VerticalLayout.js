import React, { useState, useEffect } from "react";
import {
  AppBar,
  Box,
  Drawer,
  IconButton,
  List,
  ListItem,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Toolbar,
  Typography,
} from "@mui/material";
import { useNavigate } from "react-router-dom";

import { IoMenuSharp, IoSettingsOutline } from "react-icons/io5";
import { RxDashboard } from "react-icons/rx";
import { FaUserCheck } from "react-icons/fa6";
import { BsFileRuled } from "react-icons/bs";
import { SiGoogleclassroom } from "react-icons/si";

const VerticalLayout = ({ children }) => {
  const navigate = useNavigate();

  const [collapsed, setCollapsed] = useState(false);
  const [pageTitle, setPageTitle] = useState("Dashboard");

  useEffect(() => {
    if (window.location.pathname === "/") {
      setPageTitle("Dashboard");
    } else if (window.location.pathname === "/classrooms") {
      setPageTitle("Classrooms");
    } else if (window.location.pathname === "/attendance") {
      setPageTitle("Attendance");
    } else if (window.location.pathname === "/marks") {
      setPageTitle("Marks");
    }
  }, [window.location.pathname]);

  const handleDrawerClose = () => {
    setCollapsed(!collapsed);
  };

  return (
    <div className="v_layout">
      <AppBar
        position="fixed"
        className="layout_header"
        sx={{
          width: !collapsed ? "calc(100% - 240px)" : "calc(100% - 80px)",
        }}
      >
        <Toolbar>
          <IconButton
            size="large"
            edge="start"
            color="inherit"
            aria-label="menu"
            sx={{ mr: 2, color: "#000000" }}
            onClick={handleDrawerClose}
          >
            <IoMenuSharp />
          </IconButton>
          <Typography
            variant="h6"
            component="div"
            sx={{ flexGrow: 1, color: "#000000" }}
          >
            {pageTitle}
          </Typography>
        </Toolbar>
      </AppBar>

      <Drawer
        variant="permanent"
        open={collapsed}
        className="layout_drawer"
        sx={{
          width: !collapsed ? "240px" : "80px",
          "& .MuiDrawer-paper": {
            width: !collapsed ? "240px" : "80px",
          },
        }}
      >
        <Box>
          <IconButton>{!collapsed ? "" : ""}</IconButton>
        </Box>

        <List>
          {[
            { name: "Dashboard", route: "/", icon: <RxDashboard /> },
            { name: "Classrooms", route: "/classrooms", icon: <SiGoogleclassroom /> },
            { name: "Attendance", route: "/attendance", icon: <FaUserCheck /> },
            { name: "Marks", route: "/marks", icon: <BsFileRuled /> },
            {
              name: "Settings",
              route: "/settings",
              icon: <IoSettingsOutline />,
            },
          ].map((item, index) => (
            <ListItem key={index} disablePadding sx={{ display: "block" }}>
              <ListItemButton
                sx={{
                  minHeight: 48,
                  justifyContent: !collapsed ? "initial" : "center",
                  gap: "10px",
                  px: 2.5,
                }}
                onClick={() => navigate(item?.route)}
              >
                <ListItemIcon
                  sx={{
                    minWidth: 0,
                    mr: !collapsed ? 3 : "none",
                    margin: !collapsed ? "unset" : 0,
                    justifyContent: "center",
                    // color: "#ffffff",
                    color:
                      window.location.pathname === item?.route
                        ? "var(--primary)"
                        : "#ffffff",
                  }}
                >
                  {item?.icon}
                </ListItemIcon>
                <ListItemText
                  primary={item?.name}
                  sx={{
                    opacity: !collapsed ? 1 : 0,
                    display: !collapsed ? "unset" : "none",
                    color:
                      window.location.pathname === item?.route
                        ? "var(--primary)"
                        : "#ffffff",
                  }}
                />
              </ListItemButton>
            </ListItem>
          ))}
        </List>
      </Drawer>

      <Box
        component="main"
        sx={{ padding: "100px 20px 20px 20px", width: "100%" }}
      >
        {children}
      </Box>
    </div>
  );
};

export default VerticalLayout;
